#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"

#include "proc.h"
#include "stddef.h"


uint64
sys_exit(void)
{
  int n;
  if(argint(0, &n) < 0)
    return -1;
  exit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

uint64
sys_wait(void)
{
  uint64 p;
  if(argaddr(0, &p) < 0)
    return -1;
  return wait(p);
}

uint64
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

uint64
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}


//Gets parent process ID and return it
uint64
sys_getppid(void)
{
  struct proc *p = myproc();
  struct proc *parent = p->parent;
  int ppid = parent->pid;


  return ppid;
}

extern struct proc proc[NPROC];
uint64
sys_ps(void){
  //define the ps_struct for each process and ps[NPROC] for all processes

  struct ps_struct{
    int pid;
    int ppid;
    char state[10];
    char name[16];
  } ps[NPROC];

  int numProc = 0; //variable keeping track of the number of processes in the system

  for(int i=0; i < 64; i++){
    if(proc[i].state != 0){
      ps[i].pid = proc[i].pid;
      if(proc[i].parent != 0){
        ps[i].ppid = proc[i].parent->pid;
        }else{
          ps[i].ppid = -1;
        }
      
        switch(proc[i].state){
          case 0: strncpy(ps[i].state, "UNUSED", 8);
          case 1: strncpy(ps[i].state, "USED", 5);
          case 2: strncpy(ps[i].state, "SLEEPING", 9);
          case 3: strncpy(ps[i].state, "RUNNABLE", 10);
          case 4: strncpy(ps[i].state, "RUNNING", 8);
          case 5: strncpy(ps[i].state, "ZOMBIE", 8);
        }
      //strncpy(ps[i].state, proc[i].state, 10);
      strncpy(ps[i].name, proc[i].name, 9);
      



      numProc+=1;
    }
    
  }


  //save the address of the uer space argument to arg_addr
  uint64 arg_addr;
  argaddr(0, &arg_addr);

  //copy array ps to the saved address
  if(copyout(myproc()->pagetable, arg_addr, (char*)ps, numProc*sizeof(struct ps_struct)) < 0)
    return -1;


  //return numProc as well
  return numProc;
}



uint64 sys_getschedhistory(void){
  //define the struct for reporting scheduling history 
  struct sched_history{
    int runCount;
    int systemcallCount;
    int interruptCount;
    int preemptCount;
    int trapCount;
    int sleepCount;
  } my_history;

  my_history.runCount = myproc()->runCount;
  my_history.systemcallCount = myproc()->systemccallCount;
  my_history.interruptCount = myproc()->interruptCount;
  my_history.preemptCount = myproc()->preemptCount;
  my_history.trapCount = myproc()->trapCount;
  my_history.sleepCount = myproc()->sleepCount;

  //save the address of the user space argument to arg_addr
  uint64 arg_addr;
  argaddr(0, &arg_addr);

  

  if(copyout(myproc()->pagetable, arg_addr, (char*)&my_history, sizeof(struct sched_history)) < 0)
    return -1;

  return myproc()->pid;

}



// //Addiotional System Calls for 1.C
uint64
sys_startMLFQ(int m, int n){
  //m = number of queues
  //n = number of ticks allowed at queue m-1
  mlfqFlag = 1; //Set flag for system to use MLFQ
  numberOfQueues = m; //Set global variable for num queues
  maxTicksAtBottom = n; //Set global variable for max number of ticks at lowest queue


  //Init each queue for use in scheduler
  for (int i = 0; i < m; i++) {
    queues[i].head = 0;
    queues[i].tail = 0;


    //Error handling with queues
    // if (queues[i] == NULL){
    //   return -1;
    // }
  }

  //return 0 on success
  return 0;
}


uint64
sys_stopMLFQ(void){
  //Set mlfq flag to 0 to stop using MLFQ Scheduler
  mlfqFlag = 0;

  return 0;
}


uint64
sys_getMLFQInfo(struct MLFQInfoReport *report){
  return 0;
}